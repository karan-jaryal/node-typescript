/**
 * Error DTO
 */
interface IError {
  isError: boolean,
  code: string,
  message: string
}

/**
 * @class
 * API Error class.
 */
class ApiError extends Error {
  _status: number;
  _code: string;
  /**
   * Constructor
   * @param {string} message error message
   */
  constructor(message: string, status: number, code: string) {
    super(message);
    this._status = status;
    this._code = code;
  }

  /**
   * Sends error JSON to response stream.
   * @param {Response} res Server response.
   */
  public send(res: any) {
    // set status
    res.status(this._status || 500);

    // create formatted response
    const formatedRes: IError = {
      isError: true,
      code: this._code || "INTERNAL_ERROR",
      message: this.message
    }
    // not to send complete error info if env is not development
    if (res.status == 500 && process.env.NODE_ENV !== "development") {
      formatedRes["message"] = "Something went wrong";
    }
    // send JSON
    res.json(formatedRes);
  }
  /**
   * Returns error JSON.
   */
  public get() {
    // return JSON
    return {
      isError: true,
      status: this._status || 500,
      code: this._code || "INTERNAL_ERROR",
      message: this.message
    };
  }
};

export default ApiError;
