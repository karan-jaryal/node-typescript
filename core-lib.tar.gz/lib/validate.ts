import Ajv from 'ajv';
const ajv = new Ajv({ allErrors: true,jsPropertySyntax:true });
import format from "./ajvFormat";
import  errors from './errors';
import _ from "lodash";
//inject custom format to ajv
format(ajv)

/**
 * Validate data against schema.
 * Throws API error if data is invalid.
 *
 * @param {*} data data to validate.
 * @param {object} schema ajv schema object.
 */
export = (schema:Object, data:Object) => {
    const validate = ajv.compile(schema);
    const valid = validate(data);
    if (!valid) {
        const message = ajv.errorsText(validate.errors)
        throw errors.INVALID_INPUT(message)
    }

}