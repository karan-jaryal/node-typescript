import _ from "lodash";
import asyncback from "asyncback";
/**
 * Mounts async handler on app for given method at given path.
 * @param {string} method HTTP method
 * @param {string} path route path
 * @param {function} handler handler async function
 * @param {express} app express/router instance
 */
function mount(method: string, path: string, handler: Function, meta: { isPublic: boolean }, app: any, prefix?: string) {


  let p = path;
  //adding base path if any
  if (prefix) {
    if (meta && meta.isPublic) {
      p = `${prefix}/public${path}`
    }
    else {
      p = `${prefix}${path}`
    }

  }
  //adding public routes
  if (!prefix && meta && meta.isPublic) {
    p = `/public${path}`
  }

  app[method](p, asyncback(handler));


}

// supported HTTP methods
const methods = { GET: "get", POST: "post", PUT: "put", DELETE: "delete", PATCH: "patch" }

//map HTTP methods to export
export =_.mapValues(methods, (v, k) => {
  return (path: string, handler: Function, meta?: { isPublic: boolean }) =>
    _.partial(mount, v, path, handler, meta)
})
