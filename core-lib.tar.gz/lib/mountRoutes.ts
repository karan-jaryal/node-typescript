import glob from "glob";
import _ from "lodash";
/**
 * @description traverse all route files and mount each route on app
 * @param {String} parentDir - current working directory on which search need to be done
 * @param {*} routingDir - specific folder in cwd in which files need to be search
 * @param {*} app
 */
export = async function mountRoutes(parentDir: string, routingDir: string, app: any, prefix?: string) {
  const options = { cwd: parentDir, realpath: true };
  const pattern = `**/${routingDir}/**/*{.ts,.js}`;
  glob.sync(pattern, options).forEach((routes: any) => {
    //mounting routes over app
    const route = require(routes);
    // mounting multiple routes in a single file exported in array
    if (_.isArray(route) && route.length) {
      _.map(route, r => r(app, prefix))
    }
    else {
      //if single route exported directly
      route(app, prefix)
    }
  });
}


