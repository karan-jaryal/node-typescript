import ApiError from "./ApiError";
import errors from "./errors";
import _ from "lodash";
import { Request, Response, NextFunction } from "express"
/**
 * Express error handler middleware.
 * Should be the last middleware used.
 *
 * @param {Error|*} err Error value
 * @param {Request} req Express request
 * @param {Response} res Express response
 * @param {Function} next Next function
 */
export const errorHandler =function (err: Error, req: Request, res: Response, next: NextFunction) {
  if (res.headersSent) {
    // end if headers have already been sent
    res.end();
  } else {
    // send error
    if (err instanceof ApiError) {
      //TODO:log to logger

      // send API error
      err.send(res);
    } else {
      // generic errors
      if (err instanceof Error && _.has(err, "message")) {
        //TODO:log to logger
      }
      errors.INTERNAL(err.message).send(res);
    }
  }
}
