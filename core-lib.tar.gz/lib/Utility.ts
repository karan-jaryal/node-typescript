import  _ from"lodash";
/**
 * Numeric characters string: 0-9.
 * @type {string}
 */
const NUMERIC = "0123456789";

/**
 * Utility class define common utility function that used throughout the system.
 *
 * @class Utility
 */
export class Utility {
  /**
   * Generate a string of given length of random numeric digits.
   * @param {Number} length - desired output length. Must be > 0;
   * @return {string} generated output string.
   */
  static randomNumeric(length:number) {
    if (!_.isNumber(length) || length < 1) {
      throw new Error("length should be a non zero number.");
    }

    let random = [];
    for (let i = 0; i < length; i++) {
      random.push(NUMERIC[_.random(0, NUMERIC.length - 1)]);
    }

    return random.join("");
  }

  /**
   * @description Custom schema validation for schema variable array max length.
   *
   * @param {Number} minLength
   */
  static maxArrayLimit(maxLength:number) {
    return function(val:[]) {
      return Promise.resolve(val.length <= maxLength);
    };
  }

  /**
   * @description Custom schema validation for schema variable array min length.
   *
   * @param {Number} minLength
   */
  static minArrayLimit(minLength:number) {
    return function(val:[]) {
      return Promise.resolve(val.length >= minLength);
    };
  }

}
 

