import bodyParser from "body-parser";
import errors from "./errors";
import { Request, Response, NextFunction } from "express"



export default class Parser {

  /**
 * Wraps "body-parser.json()" middleware.
 * Detects JSON parsing errors and forwards these as ApiError instances.
 *
 * @param {Object} options body-parser options.
 * @returns {Function} wrapped middleware.
 */

  static jsonParser(options: object) {
    const mw = bodyParser.json(options);
    // return wrapped middleware
    return (req: Request, res: Response, next: NextFunction) => {
      // call json parsing middleware, with interceptor
      mw(req, res, Parser.handler(next))
    };

  }

  /**
 * Wraps "body-parser.urlencoded()" middleware.
 * Detects JSON parsing errors and forwards these as ApiError instances.
 *
 * @param {Object} options body-parser options.
 * @returns {Function} wrapped middleware.
 */

  static urlencoded(options: object) {
    const mw = bodyParser.urlencoded(options);
    // return wrapped middleware
    return (req: Request, res: Response, next: NextFunction) => {
      // callurl encoded  parsing middleware, with interceptor
      mw(req, res, Parser.handler(next))
    };

  }

  /**
   * Handler to catch error and convert error to API error instance
   * @param next 
   * @returns 
   */
  private static handler(next: NextFunction) {
    return (err: Error) => {
      if (err) {
        // parsing error
        return next(errors.INVALID_INPUT());
      } else {
        // some other error
        return next(err);
      }
    }


  }

}