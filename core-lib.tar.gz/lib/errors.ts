import _ from "lodash";
import ApiError from "./ApiError";
import errorCodes from "./errorCodes";

// Transform error value into error functions
export =  _.mapValues(errorCodes, (val, key) => {
  return (message?: any) => new ApiError(message || val.message, val.status, key);
});


new Error()